function toggleMenu(opcion) {
    document.getElementById('mensajeBienvenida').classList.add('oculto');
    document.getElementById('formulario').classList.add('oculto');
    document.getElementById('saludarBtn').classList.add('oculto');

    if (opcion === 'bienvenida') {
        document.getElementById('mensajeBienvenida').classList.remove('oculto');
    } else if (opcion === 'formulario') {
        document.getElementById('formulario').classList.remove('oculto');
    }
}

function cerrarMensaje() {
    document.getElementById('mensajeBienvenida').classList.add('oculto');
}

function guardarDatos() {
    const nombre = document.getElementById('nombre').value;
    const apellido = document.getElementById('apellido').value;
    const correo = document.getElementById('correo').value;
    alert(`Datos guardados:\nNombre: ${nombre}\nApellido: ${apellido}\nCorreo: ${correo}`);
    document.getElementById('formulario').classList.add('oculto');
    document.getElementById('saludarBtn').classList.remove('oculto');
}

function saludar() {
    alert("¡Hola! Bienvenido a nuestra página web.");
}
